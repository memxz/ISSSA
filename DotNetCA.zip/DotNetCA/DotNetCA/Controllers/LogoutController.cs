﻿using Microsoft.AspNetCore.Mvc;

namespace DotNetCA.Controllers
{
    public class LogoutController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
